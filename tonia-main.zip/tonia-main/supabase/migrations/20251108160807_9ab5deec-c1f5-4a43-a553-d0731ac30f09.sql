-- Garantir que o usuário tem role de admin (ignora se já existir)
INSERT INTO public.user_roles (user_id, role)
SELECT id, 'admin'::app_role
FROM auth.users
WHERE email = 'jc.alvesnunes23@gmail.com'
ON CONFLICT (user_id, role) DO NOTHING;

-- Criar tabela para armazenar configurações de integração do WhatsApp
CREATE TABLE IF NOT EXISTS public.whatsapp_integrations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  phone_number TEXT NOT NULL,
  access_token TEXT NOT NULL,
  phone_number_id TEXT NOT NULL,
  business_account_id TEXT,
  webhook_verify_token TEXT NOT NULL,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(user_id, phone_number_id)
);

-- Habilitar RLS na tabela de integrações
ALTER TABLE public.whatsapp_integrations ENABLE ROW LEVEL SECURITY;

-- Políticas RLS: apenas admins podem gerenciar integrações
CREATE POLICY "Admins can manage WhatsApp integrations"
ON public.whatsapp_integrations
FOR ALL
TO authenticated
USING (public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Criar tabela para mensagens do WhatsApp
CREATE TABLE IF NOT EXISTS public.whatsapp_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  integration_id UUID REFERENCES public.whatsapp_integrations(id) ON DELETE CASCADE NOT NULL,
  conversation_id UUID REFERENCES public.conversations(id) ON DELETE CASCADE,
  whatsapp_message_id TEXT NOT NULL UNIQUE,
  from_number TEXT NOT NULL,
  to_number TEXT NOT NULL,
  message_type TEXT NOT NULL,
  message_body TEXT,
  media_url TEXT,
  status TEXT DEFAULT 'received',
  timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Habilitar RLS na tabela de mensagens do WhatsApp
ALTER TABLE public.whatsapp_messages ENABLE ROW LEVEL SECURITY;

-- Políticas RLS: apenas admins podem ver mensagens
CREATE POLICY "Admins can view WhatsApp messages"
ON public.whatsapp_messages
FOR SELECT
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Edge function pode inserir mensagens (webhook)
CREATE POLICY "Service role can insert WhatsApp messages"
ON public.whatsapp_messages
FOR INSERT
TO authenticated
WITH CHECK (true);

-- Criar função para atualizar timestamp
CREATE OR REPLACE FUNCTION public.update_whatsapp_integration_timestamp()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;

-- Criar trigger para atualizar timestamp automaticamente
CREATE TRIGGER update_whatsapp_integration_updated_at
BEFORE UPDATE ON public.whatsapp_integrations
FOR EACH ROW
EXECUTE FUNCTION public.update_whatsapp_integration_timestamp();