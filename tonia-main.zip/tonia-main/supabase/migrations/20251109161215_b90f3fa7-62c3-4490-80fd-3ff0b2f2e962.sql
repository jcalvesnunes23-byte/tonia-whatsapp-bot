-- Restrict messages and conversations tables to service role only
-- This prevents anonymous spam while maintaining edge function access

-- Drop existing permissive policies
DROP POLICY IF EXISTS "Anyone can insert messages" ON public.messages;
DROP POLICY IF EXISTS "Anyone can create conversations" ON public.conversations;

-- Create new restrictive policies for messages
CREATE POLICY "Service role can insert messages" ON public.messages
FOR INSERT WITH CHECK (auth.role() = 'service_role');

-- Create new restrictive policies for conversations  
CREATE POLICY "Service role can create conversations" ON public.conversations
FOR INSERT WITH CHECK (auth.role() = 'service_role');