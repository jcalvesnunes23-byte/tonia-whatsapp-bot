import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Input validation schema
const requestSchema = z.object({
  messages: z.array(z.object({
    role: z.enum(['user', 'assistant', 'system']),
    content: z.string().max(4000, 'Message too long')
  })).min(1, 'At least one message required').max(50, 'Too many messages'),
  conversationId: z.string().uuid().optional(),
  userIdentifier: z.string().max(100, 'User identifier too long')
});

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const rawBody = await req.text();
    
    // Check request size limit (50KB)
    if (rawBody.length > 50000) {
      return new Response(
        JSON.stringify({ error: "Request too large" }),
        { status: 413, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
    
    let body;
    try {
      body = JSON.parse(rawBody);
    } catch {
      return new Response(
        JSON.stringify({ error: "Invalid JSON" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
    
    // Validate input
    const validated = requestSchema.parse(body);
    const { messages, conversationId, userIdentifier } = validated;
    console.log('Received chat request:', { conversationId, userIdentifier, messageCount: messages.length });
    
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      console.error('LOVABLE_API_KEY not configured');
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    // Criar cliente Supabase
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Criar ou obter conversa
    let convId = conversationId;
    if (!convId) {
      const { data: newConv, error: convError } = await supabase
        .from('conversations')
        .insert({ user_identifier: userIdentifier || 'anonymous' })
        .select()
        .single();
      
      if (convError) {
        console.error('Error creating conversation:', convError);
        throw convError;
      }
      convId = newConv.id;
      console.log('Created new conversation:', convId);
    }

    // Salvar mensagem do usuário
    const userMessage = messages[messages.length - 1];
    await supabase
      .from('messages')
      .insert({
        conversation_id: convId,
        role: 'user',
        content: userMessage.content
      });
    console.log('Saved user message');

    // Chamar IA com prompt estratégico de vendas persuasivas
    const systemPrompt = `⚙️ FUNÇÃO PRINCIPAL:
Você é a TonIA — uma inteligência artificial vendedora da Ton, conectada ao WhatsApp via QR Code.  
Sua missão é vender maquininhas Ton automaticamente, guiando o cliente da curiosidade até o fechamento da compra.  
Você deve responder com base em informações reais e atualizadas sobre os produtos Ton e seguir técnicas de persuasão inspiradas nos livros:
- "As 48 Leis do Poder" (Robert Greene)
- "Como Fazer Amigos e Influenciar Pessoas" (Dale Carnegie)
- "As Armas da Persuasão" (Robert Cialdini)
Use linguagem natural, empática e estratégica para influenciar decisões.

💬 PRODUTOS E VALORES ATUAIS:
- T3 Ton Pro (Site): R$115,74  
- T3 Ton Max – MEI e PJ: R$160,92  
- T3 Smart Ton Super: R$152,28  
- T3 Smart Ton Super (Site): R$177,18  
- T3 Smart Ton Max – MEI e PJ: R$171,00  
Todos com **frete grátis** e **entrega de 1 a 3 dias úteis**.

📈 OBJETIVO:
1. Receber o cliente de forma calorosa e simpática.  
2. Identificar se ele é **Pessoa Física ou MEI/PJ** (isso define a maquininha ideal).  
3. Apresentar o modelo certo, destacando benefícios como:
   - Taxas mais baixas do Brasil;
   - Entrega rápida e sem custo;
   - Suporte completo da Ton;
   - Facilidade de uso e segurança.  
4. Criar gatilhos mentais de escassez e autoridade: use expressões como  
   "Essa promoção é por tempo limitado" e "A Ton é referência nacional em soluções de pagamento".
5. Conduzir o cliente até o fechamento com uma chamada clara para ação:  
   👉 "Posso gerar o link da maquininha ideal pra você agora?"
6. Capturar dados de contato (nome, telefone, cidade) quando relevante para o processo de venda.

🧩 COMPORTAMENTO:
- Sempre mantenha o tom natural, empático e humano.
- Se o cliente disser que vai pensar, use gatilhos sutis para manter o interesse.
- Se ele tiver dúvidas sobre taxas, explique que "as taxas variam conforme o tipo de venda, mas a Ton sempre garante a menor taxa do Brasil".
- Se o cliente já tiver uma maquininha, mostre as vantagens de migrar para a Ton.

🎯 FOCO:
Transforme cada conversa em venda.
A TonIA deve agir como uma vendedora digital experiente: simpática, objetiva e persuasiva.
Nunca force, mas sempre direcione o cliente para o fechamento.

IMPORTANTE: Adapte-se naturalmente ao contexto da conversa.`;

    console.log('Calling Lovable AI...');
    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "openai/gpt-5-mini",
        messages: [
          { role: "system", content: systemPrompt },
          ...messages,
        ],
        stream: false,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('AI gateway error:', response.status, errorText);
      
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: "Limite de requisições excedido. Tente novamente em alguns instantes." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: "Créditos esgotados. Por favor, adicione créditos ao workspace." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      
      throw new Error("AI gateway error");
    }

    const data = await response.json();
    const assistantMessage = data.choices[0].message.content;
    console.log('Received AI response');

    // Salvar resposta da IA
    await supabase
      .from('messages')
      .insert({
        conversation_id: convId,
        role: 'assistant',
        content: assistantMessage
      });
    console.log('Saved assistant message');

    return new Response(
      JSON.stringify({ 
        message: assistantMessage,
        conversationId: convId 
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Error in ai-chat function:", error);
    
    // Handle validation errors
    if (error instanceof z.ZodError) {
      return new Response(
        JSON.stringify({ error: "Invalid input: " + error.errors[0].message }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
    
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});