import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.80.0";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Webhook verification (GET request from WhatsApp)
    if (req.method === 'GET') {
      const url = new URL(req.url);
      const mode = url.searchParams.get('hub.mode');
      const token = url.searchParams.get('hub.verify_token');
      const challenge = url.searchParams.get('hub.challenge');

      console.log('Webhook verification:', { mode, token, challenge });

      // Verify token
      const { data: integration } = await supabase
        .from('whatsapp_integrations')
        .select('webhook_verify_token')
        .eq('webhook_verify_token', token)
        .maybeSingle();

      if (mode === 'subscribe' && integration) {
        console.log('Webhook verified successfully');
        return new Response(challenge, { 
          status: 200,
          headers: { 'Content-Type': 'text/plain' }
        });
      } else {
        console.error('Webhook verification failed');
        return new Response('Forbidden', { status: 403 });
      }
    }

    // Handle incoming messages (POST request)
    if (req.method === 'POST') {
      const contentType = req.headers.get('content-type') || '';
      let body;
      
      // Handle both JSON and form-urlencoded data
      if (contentType.includes('application/json')) {
        body = await req.json();
      } else if (contentType.includes('application/x-www-form-urlencoded')) {
        const text = await req.text();
        const params = new URLSearchParams(text);
        const jsonData = params.get('jsonData');
        body = jsonData ? JSON.parse(jsonData) : {};
      } else {
        // Try to parse as JSON by default
        const text = await req.text();
        try {
          body = JSON.parse(text);
        } catch {
          console.error('Could not parse body:', text);
          return new Response(JSON.stringify({ error: 'Invalid body format' }), {
            status: 400,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          });
        }
      }
      
      console.log('Received webhook:', JSON.stringify(body, null, 2));

      // Extract message data from WhatsApp webhook
      const entry = body.entry?.[0];
      const changes = entry?.changes?.[0];
      const value = changes?.value;
      const messages = value?.messages;

      if (!messages || messages.length === 0) {
        console.log('No messages in webhook');
        return new Response(JSON.stringify({ success: true }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      const message = messages[0];
      const fromNumber = message.from;
      const messageId = message.id;
      const messageType = message.type;
      const messageBody = message.text?.body || message.caption || '';

      console.log('Processing message:', { fromNumber, messageId, messageType, messageBody });

      // Find the integration for this phone number
      const phoneNumberId = value?.metadata?.phone_number_id;
      const { data: integration, error: integrationError } = await supabase
        .from('whatsapp_integrations')
        .select('*')
        .eq('phone_number_id', phoneNumberId)
        .eq('is_active', true)
        .maybeSingle();

      if (integrationError || !integration) {
        console.error('Integration not found:', integrationError);
        return new Response(JSON.stringify({ error: 'Integration not found' }), {
          status: 404,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // Create or get conversation
      const { data: conversation, error: convError } = await supabase
        .from('conversations')
        .select('id')
        .eq('user_identifier', `whatsapp:${fromNumber}`)
        .maybeSingle();

      let conversationId = conversation?.id;

      if (!conversationId) {
        const { data: newConv, error: newConvError } = await supabase
          .from('conversations')
          .insert({ user_identifier: `whatsapp:${fromNumber}` })
          .select('id')
          .single();

        if (newConvError) {
          console.error('Error creating conversation:', newConvError);
          throw newConvError;
        }
        conversationId = newConv.id;
      }

      // Store the WhatsApp message
      const { error: msgError } = await supabase
        .from('whatsapp_messages')
        .insert({
          integration_id: integration.id,
          conversation_id: conversationId,
          whatsapp_message_id: messageId,
          from_number: fromNumber,
          to_number: phoneNumberId,
          message_type: messageType,
          message_body: messageBody,
          status: 'received',
        });

      if (msgError) {
        console.error('Error storing WhatsApp message:', msgError);
        throw msgError;
      }

      // Store user message in messages table
      const { error: userMsgError } = await supabase
        .from('messages')
        .insert({
          conversation_id: conversationId,
          role: 'user',
          content: messageBody,
        });

      if (userMsgError) {
        console.error('Error storing user message:', userMsgError);
      }

      // Get conversation history for AI context
      const { data: history } = await supabase
        .from('messages')
        .select('role, content')
        .eq('conversation_id', conversationId)
        .order('created_at', { ascending: true });

      // Check for conditional responses based on keywords
      const messageLower = messageBody.toLowerCase();
      let conditionalResponses: string[] = [];
      
      // Branch logic based on message content
      if (messageLower.includes('comprar')) {
        conditionalResponses.push('Perfeito! 💳 Me diga rapidinho: você é Pessoa Física ou MEI/PJ? Assim consigo te mostrar a maquininha com a menor taxa e pronta pra entrega.');
      } else if (messageLower.includes('mei') || messageLower.includes('pj')) {
        conditionalResponses.push('Ótimo! 🙌 O modelo ideal pra MEI e PJ é a **T3 Ton Max**, apenas R$160,92, frete grátis e entrega de 1 a 3 dias úteis. Quer que eu gere o link pra você?');
      } else if (messageLower.includes('pessoa física') || messageLower.includes('pessoa fisica')) {
        conditionalResponses.push('Perfeito! 💚 A maquininha ideal pra Pessoa Física é a **T3 Ton Pro**, por apenas R$115,74, com frete grátis e entrega de 1 a 3 dias úteis. Posso gerar o link pra você agora?');
      } else if (messageLower.includes('sim') && history && history.length > 0) {
        const lastMessage = history[history.length - 1]?.content?.toLowerCase() || '';
        if (lastMessage.includes('link') || lastMessage.includes('gerar')) {
          conditionalResponses.push('Show! 😎 Aqui está o link pra você garantir a sua: https://ton.com.br/maquininha');
          conditionalResponses.push('Lembrando: as taxas da Ton são as **mais baixas do Brasil**, e o frete é grátis 🚚💨');
        }
      }

      let aiMessage = '';
      
      // Use conditional responses if available, otherwise call AI
      if (conditionalResponses.length > 0) {
        aiMessage = conditionalResponses.join('\n\n');
        console.log('Using conditional response:', aiMessage);
      } else {
        // Call AI to generate response
        const { data: aiResponse, error: aiError } = await supabase.functions.invoke('ai-chat', {
          body: {
            messages: history || [],
            conversationId,
            userIdentifier: `whatsapp:${fromNumber}`,
          },
        });

        if (aiError) {
          console.error('Error calling AI:', aiError);
          throw aiError;
        }

        aiMessage = aiResponse.message || aiResponse.response || 'Desculpe, não consegui processar sua mensagem.';
        console.log('Using AI response:', aiMessage);
      }

      // Send response back to WhatsApp
      const whatsappApiUrl = `https://graph.facebook.com/v18.0/${phoneNumberId}/messages`;
      const whatsappResponse = await fetch(whatsappApiUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${integration.access_token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          messaging_product: 'whatsapp',
          to: fromNumber,
          type: 'text',
          text: { body: aiMessage },
        }),
      });

      if (!whatsappResponse.ok) {
        const error = await whatsappResponse.text();
        console.error('WhatsApp API error:', error);
        throw new Error(`WhatsApp API error: ${error}`);
      }

      const whatsappData = await whatsappResponse.json();
      console.log('Message sent successfully:', whatsappData);

      // Store sent message
      const { error: sentMsgError } = await supabase
        .from('whatsapp_messages')
        .insert({
          integration_id: integration.id,
          conversation_id: conversationId,
          whatsapp_message_id: whatsappData.messages[0].id,
          from_number: phoneNumberId,
          to_number: fromNumber,
          message_type: 'text',
          message_body: aiMessage,
          status: 'sent',
        });

      if (sentMsgError) {
        console.error('Error storing sent message:', sentMsgError);
      }

      return new Response(JSON.stringify({ success: true }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    return new Response('Method not allowed', { status: 405 });

  } catch (error) {
    console.error('Webhook error:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(JSON.stringify({ error: errorMessage }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
