# TonIA Baileys Driver - WhatsApp QR Code Integration

## ⚠️ IMPORTANTE

Este código **NÃO roda no Lovable**. Você precisa executá-lo em um **servidor Node.js separado** como:
- VPS (DigitalOcean, Linode, AWS EC2, etc.)
- Railway.app
- Render.com
- Heroku
- Seu computador local (para testes)

## 📋 Pré-requisitos

- Node.js 16+ instalado
- Número de WhatsApp Business (recomendado) ou pessoal
- Servidor com IP público ou ngrok para testes

## 🚀 Como rodar

### 1. Instalar dependências

```bash
cd baileys-driver
npm install
```

### 2. Configurar variáveis de ambiente

Copie `.env.example` para `.env` e configure:

```bash
cp .env.example .env
```

Edite o `.env`:

```env
PORT=3001
TONIA_WEBHOOK=https://SEU_PROJETO.supabase.co/functions/v1/whatsapp-webhook
DRIVER_SECRET=seu_secret_super_seguro_aqui
WHATSAPP_PHONE_NUMBER_ID=baileys_driver
```

### 3. Iniciar o servidor

```bash
npm start
```

### 4. Escanear QR Code

1. Acesse `http://localhost:3001/qr` no navegador
2. Escaneie o QR code com o WhatsApp no celular:
   - Abra WhatsApp
   - Toque nos 3 pontos (⋮) > Aparelhos conectados
   - Toque em "Conectar um aparelho"
   - Escaneie o QR code na tela

3. Aguarde a conexão (verá "✅ Conectado ao WhatsApp com sucesso!" no console)

## 🔗 Endpoints

### GET /qr
Exibe o QR code para autenticação WhatsApp

### GET /ping
Health check do servidor

### POST /sendMessage
Envia mensagem via WhatsApp (usado pela TonIA)

**Headers:**
```
Authorization: Bearer SEU_DRIVER_SECRET
Content-Type: application/json
```

**Body:**
```json
{
  "to": "+5511999999999",
  "text": "Mensagem da TonIA"
}
```

## 🔧 Integração com TonIA

O driver envia mensagens recebidas do WhatsApp para o webhook configurado em `TONIA_WEBHOOK`.

**Formato do payload enviado:**
```json
{
  "entry": [{
    "changes": [{
      "value": {
        "messages": [{
          "from": "5511999999999",
          "id": "message_id",
          "type": "text",
          "text": { "body": "mensagem do cliente" }
        }],
        "metadata": {
          "phone_number_id": "baileys_driver"
        }
      }
    }]
  }]
}
```

## 🛡️ Segurança

1. **Nunca exponha o DRIVER_SECRET** - use um valor forte e aleatório
2. Use **HTTPS** em produção (obrigatório para webhooks)
3. Configure firewall para permitir apenas IPs necessários
4. Para produção, considere migrar para **WhatsApp Cloud API oficial**

## 🐛 Troubleshooting

### QR não aparece / não conecta
- Verifique se o horário do servidor está correto
- Apague `auth_info_multi.json` e reinicie
- Verifique logs no console

### Mensagens não chegam na TonIA
- Verifique se `TONIA_WEBHOOK` está correto
- Teste o webhook manualmente com curl/Postman
- Verifique logs de ambos os servidores

### Desconecta frequentemente
- Verifique conexão de internet do servidor
- WhatsApp pode desconectar se detectar uso suspeito
- Considere usar WhatsApp Cloud API para produção

### Erro "unauthorized" ao enviar mensagem
- Verifique se `DRIVER_SECRET` está correto
- Confirme que o header `Authorization` está sendo enviado

## ⚠️ Avisos Legais

- **Baileys é uma biblioteca não-oficial** e pode violar os Termos de Serviço do WhatsApp
- Use **apenas para desenvolvimento e testes**
- Para produção, use **WhatsApp Cloud API oficial**: https://developers.facebook.com/docs/whatsapp
- O uso inadequado pode resultar em **banimento do número**

## 📚 Recursos

- [Baileys GitHub](https://github.com/WhiskeySockets/Baileys)
- [WhatsApp Cloud API](https://developers.facebook.com/docs/whatsapp)
- [TonIA Documentation](../README.md)

## 🆘 Suporte

Para problemas com:
- **Baileys**: Abra issue no repositório oficial
- **TonIA**: Contate o suporte do projeto
- **WhatsApp Cloud API**: Use o suporte oficial do Meta
