/**
 * TonIA Baileys Driver - WhatsApp QR Code Integration
 * 
 * IMPORTANTE: Este código deve rodar em um servidor Node.js SEPARADO
 * (VPS, Railway, Render, Heroku, etc.) - NÃO roda no Lovable/Edge Functions
 * 
 * Funcionalidades:
 * - Gera QR code para autenticação WhatsApp
 * - Recebe mensagens do WhatsApp e envia para TonIA webhook
 * - Expõe endpoint /sendMessage para TonIA enviar respostas
 * 
 * ATENÇÃO: Uso de bibliotecas não-oficiais pode violar TOS do WhatsApp.
 * Para produção, considere WhatsApp Cloud API oficial.
 */

require('dotenv').config();
const makeWASocket = require('@adiwajshing/baileys').default;
const { useSingleFileAuthState } = require('@adiwajshing/baileys');
const P = require('@adiwajshing/baileys').pino;
const express = require('express');
const cors = require('cors');
const qrcode = require('qrcode');
const fetch = require('node-fetch');

const PORT = process.env.PORT || 3001;
const AUTH_FILE = process.env.AUTH_FILE || './auth_info_multi.json';
const TONIA_WEBHOOK = process.env.TONIA_WEBHOOK || 'https://thraezhbnxzgkzgszjsy.supabase.co/functions/v1/whatsapp-webhook';
const DRIVER_SECRET = process.env.DRIVER_SECRET || 'change_this_secret';

// Auth state persistence
const { state, saveState } = useSingleFileAuthState(AUTH_FILE);

const app = express();
app.use(cors());
app.use(express.json());

// Global socket reference
let sock = null;
let qrSvgDataUrl = null;

async function startSock() {
  console.log('🚀 Iniciando Baileys socket...');
  sock = makeWASocket({
    logger: P({ level: 'silent' }),
    printQRInTerminal: false,
    auth: state,
    browser: ['TonIA-Driver', 'Chrome', '1.0.0']
  });

  // Save auth state on changes
  sock.ev.on('creds.update', saveState);

  // Connection updates (qr, open, close)
  sock.ev.on('connection.update', (update) => {
    const { connection, lastDisconnect, qr } = update;
    
    if (qr) {
      // Generate dataURL QR for web endpoint
      qrcode.toDataURL(qr).then(url => {
        qrSvgDataUrl = url;
        console.log(`📱 QR code gerado — acesse http://localhost:${PORT}/qr e escaneie com WhatsApp`);
      }).catch(console.error);
      
      // Also log ASCII in terminal
      qrcode.toString(qr, { type: 'terminal' }, (err, ascii) => {
        if (!err) console.log(ascii);
      });
    }
    
    if (connection === 'open') {
      console.log('✅ Conectado ao WhatsApp com sucesso!');
      qrSvgDataUrl = null;
    }
    
    if (connection === 'close') {
      const shouldReconnect = (lastDisconnect?.error?.output?.statusCode !== 401);
      console.log('⚠️  Conexão fechada, reconectando?', shouldReconnect);
      if (shouldReconnect) {
        setTimeout(() => startSock().catch(console.error), 5000);
      }
    }
  });

  // Handle incoming messages
  sock.ev.on('messages.upsert', async (m) => {
    try {
      const messages = m.messages || [];
      for (const msg of messages) {
        if (!msg.message) continue;
        if (msg.key?.fromMe) continue; // Ignore own messages

        const from = msg.key.remoteJid; // ex: "5511999999999@s.whatsapp.net"
        const text = msg.message.conversation 
          || msg.message.extendedTextMessage?.text 
          || '';
        
        if (!text) continue;

        const messageId = msg.key.id;
        const phone = from.split('@')[0];

        const payload = {
          entry: [{
            changes: [{
              value: {
                messages: [{
                  from: phone,
                  id: messageId,
                  type: 'text',
                  text: { body: text }
                }],
                metadata: {
                  phone_number_id: process.env.WHATSAPP_PHONE_NUMBER_ID || 'baileys_driver'
                }
              }
            }]
          }]
        };

        console.log('📩 [INCOMING]', phone, text);

        // Forward to TonIA webhook
        try {
          const response = await fetch(TONIA_WEBHOOK, {
            method: 'POST',
            headers: { 
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${DRIVER_SECRET}`
            },
            body: JSON.stringify(payload)
          });

          if (!response.ok) {
            console.error('❌ Erro ao enviar para TonIA:', response.status, await response.text());
          } else {
            console.log('✅ Mensagem enviada para TonIA');
          }
        } catch (err) {
          console.error('❌ Erro ao chamar webhook TonIA:', err.message);
        }
      }
    } catch (err) {
      console.error('❌ messages.upsert error', err);
    }
  });
}

// Express endpoints

// Health check
app.get('/ping', (req, res) => res.json({ ok: true, status: 'running' }));

// Show QR to scan
app.get('/qr', (req, res) => {
  if (!qrSvgDataUrl) {
    return res.send(`
      <html>
        <head><title>TonIA QR Code</title></head>
        <body style="font-family: sans-serif; text-align: center; padding: 50px;">
          <h2>⏳ QR não disponível</h2>
          <p>Aguarde a geração do QR ou verifique o console para ASCII QR.</p>
          <p><a href="/qr">Recarregar</a></p>
        </body>
      </html>
    `);
  }
  res.setHeader('Content-Type', 'text/html');
  res.send(`
    <html>
      <head><title>TonIA QR Code</title></head>
      <body style="font-family: sans-serif; text-align: center; padding: 50px;">
        <h2>📱 Escaneie o QR com o WhatsApp</h2>
        <img src="${qrSvgDataUrl}" style="max-width: 400px; border: 2px solid #25D366; padding: 20px;" />
        <p style="color: #666;">Após escanear, a conexão será aberta automaticamente.</p>
      </body>
    </html>
  `);
});

// Send message from TonIA -> WhatsApp
app.post('/sendMessage', (req, res) => {
  const auth = req.headers['authorization'];
  if (!auth || auth !== `Bearer ${DRIVER_SECRET}`) {
    return res.status(401).json({ error: 'unauthorized' });
  }
  
  const { to, text } = req.body;
  if (!to || !text) {
    return res.status(400).json({ error: 'to and text required' });
  }

  if (!sock) {
    return res.status(503).json({ error: 'WhatsApp not connected' });
  }

  // Normalize to JID format
  const jid = to.includes('@') ? to : `${to.replace(/\+/g, '')}@s.whatsapp.net`;

  sock.sendMessage(jid, { text })
    .then(resp => {
      console.log('📤 [OUTGOING]', to, text);
      res.json({ status: 'sent', messageId: resp.key.id });
    })
    .catch(err => {
      console.error('❌ sendMessage error', err);
      res.status(500).json({ error: err.message });
    });
});

// Start server + socket
app.listen(PORT, async () => {
  console.log(`🚀 TonIA Baileys Driver rodando na porta ${PORT}`);
  console.log(`📱 Acesse http://localhost:${PORT}/qr para ver o QR code`);
  console.log(`🔗 Webhook TonIA: ${TONIA_WEBHOOK}`);
  await startSock();
});
