import Header from "@/components/Header";
import Hero from "@/components/Hero";
import Problems from "@/components/Problems";
import Features from "@/components/Features";
import ChatDemo from "@/components/ChatDemo";
import LeadForm from "@/components/LeadForm";
import CTA from "@/components/CTA";

const Index = () => {
  return (
    <div className="min-h-screen">
      <Header />
      <main className="pt-20">
        <div id="hero">
          <Hero />
        </div>
        <Problems />
        <div id="features">
          <Features />
        </div>
        <ChatDemo />
        <LeadForm />
        <CTA />
      </main>
      <footer className="bg-dark-surface py-8 text-center text-white/60 text-sm">
        <p>© 2025 TonAI. Todos os direitos reservados.</p>
      </footer>
    </div>
  );
};

export default Index;
