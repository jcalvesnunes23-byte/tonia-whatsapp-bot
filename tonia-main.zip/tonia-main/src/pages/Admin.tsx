import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { SidebarProvider } from "@/components/ui/sidebar";
import { 
  Users, TrendingUp, 
  Mail, Phone, Calendar, Clock, MessageSquare
} from "lucide-react";
import WhatsAppIntegration from "@/components/admin/WhatsAppIntegration";
import AISettings from "@/components/admin/AISettings";
import { BaileysSetup } from "@/components/admin/BaileysSetup";
import { AdminSidebar } from "@/components/admin/AdminSidebar";
import type { User, Session } from "@supabase/supabase-js";

interface Lead {
  id: string;
  name: string | null;
  email: string | null;
  phone: string | null;
  interest: string | null;
  created_at: string;
}

interface Conversation {
  id: string;
  user_identifier: string;
  created_at: string;
  updated_at: string;
  message_count?: number;
}

const Admin = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [leads, setLeads] = useState<Lead[]>([]);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [stats, setStats] = useState({
    totalLeads: 0,
    totalConversations: 0,
    todayLeads: 0,
  });
  const [activeTab, setActiveTab] = useState("leads");

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      setSession(session);
      setUser(session?.user ?? null);
      
      if (!session) {
        navigate("/auth");
      }
    });

    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      
      if (!session) {
        navigate("/auth");
      } else {
        checkAdminRole(session.user.id);
      }
    });

    return () => subscription.unsubscribe();
  }, [navigate]);

  const checkAdminRole = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', userId)
        .eq('role', 'admin')
        .maybeSingle();

      if (error) throw error;
      
      setIsAdmin(!!data);
      
      if (!data) {
        toast({
          title: "Acesso negado",
          description: "Você não tem permissão de administrador.",
          variant: "destructive",
        });
        navigate("/");
      } else {
        loadData();
      }
    } catch (error: any) {
      console.error('Error checking admin role:', error);
      toast({
        title: "Erro",
        description: "Não foi possível verificar permissões.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const loadData = async () => {
    try {
      // Carregar leads
      const { data: leadsData, error: leadsError } = await supabase
        .from('leads')
        .select('*')
        .order('created_at', { ascending: false });

      if (leadsError) throw leadsError;
      setLeads(leadsData || []);

      // Carregar conversas
      const { data: convsData, error: convsError } = await supabase
        .from('conversations')
        .select('*')
        .order('updated_at', { ascending: false });

      if (convsError) throw convsError;
      setConversations(convsData || []);

      // Calcular estatísticas
      const today = new Date().toISOString().split('T')[0];
      const todayLeads = leadsData?.filter(lead => 
        lead.created_at.startsWith(today)
      ).length || 0;

      setStats({
        totalLeads: leadsData?.length || 0,
        totalConversations: convsData?.length || 0,
        todayLeads,
      });
    } catch (error: any) {
      console.error('Error loading data:', error);
      toast({
        title: "Erro ao carregar dados",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate("/");
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground">Carregando...</p>
        </div>
      </div>
    );
  }

  if (!isAdmin) {
    return null;
  }

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-background">
        <AdminSidebar 
          activeTab={activeTab}
          onTabChange={setActiveTab}
          onLogout={handleLogout}
        />
        
        <main className="flex-1 overflow-auto">
          <div className="container mx-auto px-4 py-8">
            {/* Stats Cards */}
            <div className="grid md:grid-cols-3 gap-6 mb-8">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total de Leads</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats.totalLeads}</div>
                  <p className="text-xs text-muted-foreground">
                    {stats.todayLeads} hoje
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Conversas</CardTitle>
                  <MessageSquare className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats.totalConversations}</div>
                  <p className="text-xs text-muted-foreground">
                    Total de conversas
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Taxa de Conversão</CardTitle>
                  <TrendingUp className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {stats.totalConversations > 0 
                      ? Math.round((stats.totalLeads / stats.totalConversations) * 100)
                      : 0}%
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Leads / Conversas
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Content */}
            <div className="space-y-4">
              {activeTab === "leads" && (
                <Card>
                  <CardHeader>
                    <CardTitle>Leads Capturados</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {leads.length === 0 ? (
                        <p className="text-center text-muted-foreground py-8">
                          Nenhum lead capturado ainda.
                        </p>
                      ) : (
                        leads.map((lead) => (
                          <div
                            key={lead.id}
                            className="flex items-start gap-4 p-4 border border-border rounded-lg hover:bg-muted/50 transition-colors"
                          >
                            <div className="flex-1">
                              <h3 className="font-semibold text-foreground">
                                {lead.name || 'Nome não informado'}
                              </h3>
                              <div className="flex flex-wrap gap-4 mt-2 text-sm text-muted-foreground">
                                {lead.email && (
                                  <div className="flex items-center gap-1">
                                    <Mail className="w-4 h-4" />
                                    {lead.email}
                                  </div>
                                )}
                                {lead.phone && (
                                  <div className="flex items-center gap-1">
                                    <Phone className="w-4 h-4" />
                                    {lead.phone}
                                  </div>
                                )}
                              </div>
                              {lead.interest && (
                                <p className="text-sm text-muted-foreground mt-2">
                                  Interesse: {lead.interest}
                                </p>
                              )}
                            </div>
                            <div className="text-sm text-muted-foreground flex items-center gap-1">
                              <Calendar className="w-4 h-4" />
                              {new Date(lead.created_at).toLocaleDateString('pt-BR')}
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </CardContent>
                </Card>
              )}

              {activeTab === "conversations" && (
                <Card>
                  <CardHeader>
                    <CardTitle>Histórico de Conversas</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {conversations.length === 0 ? (
                        <p className="text-center text-muted-foreground py-8">
                          Nenhuma conversa registrada ainda.
                        </p>
                      ) : (
                        conversations.map((conv) => (
                          <div
                            key={conv.id}
                            className="flex items-center justify-between p-4 border border-border rounded-lg hover:bg-muted/50 transition-colors"
                          >
                            <div>
                              <h3 className="font-semibold text-foreground">
                                {conv.user_identifier}
                              </h3>
                              <p className="text-sm text-muted-foreground mt-1">
                                ID: {conv.id.slice(0, 8)}...
                              </p>
                            </div>
                            <div className="text-sm text-muted-foreground flex items-center gap-1">
                              <Clock className="w-4 h-4" />
                              {new Date(conv.updated_at).toLocaleString('pt-BR')}
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </CardContent>
                </Card>
              )}

              {activeTab === "whatsapp" && <WhatsAppIntegration />}
              
              {activeTab === "baileys" && <BaileysSetup />}
              
              {activeTab === "ai" && <AISettings />}
            </div>
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
};

export default Admin;