import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Send, Bot, User } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface Message {
  id: number;
  text: string;
  isBot: boolean;
}

const ChatDemo = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      text: "Olá! Sou sua assistente especializada em maquininhas Ton. Como posso ajudar você hoje? 😊",
      isBot: true
    }
  ]);
  const [inputValue, setInputValue] = useState("");
  const [loading, setLoading] = useState(false);
  const [conversationId, setConversationId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!inputValue.trim() || loading) return;

    const userMessage: Message = {
      id: messages.length + 1,
      text: inputValue,
      isBot: false
    };

    setMessages(prev => [...prev, userMessage]);
    const currentInput = inputValue;
    setInputValue("");
    setLoading(true);

    try {
      const { data, error } = await supabase.functions.invoke('ai-chat', {
        body: {
          messages: [
            ...messages.map(m => ({
              role: m.isBot ? 'assistant' : 'user',
              content: m.text
            })),
            { role: 'user', content: currentInput }
          ],
          conversationId,
          userIdentifier: `demo-user-${Date.now()}`
        }
      });

      if (error) throw error;

      if (!conversationId && data.conversationId) {
        setConversationId(data.conversationId);
      }

      const botMessage: Message = {
        id: messages.length + 2,
        text: data.message,
        isBot: true
      };

      setMessages(prev => [...prev, botMessage]);
    } catch (error: any) {
      console.error('Error calling AI:', error);
      toast({
        title: "Erro",
        description: "Não foi possível enviar a mensagem. Tente novamente.",
        variant: "destructive"
      });
      
      // Mensagem de fallback
      const fallbackMessage: Message = {
        id: messages.length + 2,
        text: "Desculpe, estou com dificuldades no momento. Por favor, tente novamente em alguns instantes.",
        isBot: true
      };
      setMessages(prev => [...prev, fallbackMessage]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <section id="chatbot-demo" className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl lg:text-5xl font-bold text-foreground mb-4">
            Veja a IA em Ação
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Teste abaixo como a IA responde perguntas e conduz vendas automaticamente
          </p>
        </div>

        <div className="max-w-3xl mx-auto">
          <div className="bg-card border border-border rounded-3xl shadow-card overflow-hidden">
            {/* Chat Header */}
            <div className="bg-gradient-primary p-6 flex items-center gap-3">
              <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center">
                <Bot className="w-7 h-7 text-primary" />
              </div>
              <div>
                <h3 className="text-white font-bold text-lg">Assistente Ton AI</h3>
                <p className="text-white/80 text-sm">Online • Responde em segundos</p>
              </div>
            </div>

            {/* Messages */}
            <div className="h-[500px] overflow-y-auto p-6 space-y-4 bg-muted/20">
              {messages.map((message) => (
                <div 
                  key={message.id}
                  className={`flex items-start gap-3 ${message.isBot ? '' : 'flex-row-reverse'}`}
                >
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
                    message.isBot 
                      ? 'bg-gradient-primary' 
                      : 'bg-secondary'
                  }`}>
                    {message.isBot ? (
                      <Bot className="w-5 h-5 text-white" />
                    ) : (
                      <User className="w-5 h-5 text-primary" />
                    )}
                  </div>
                  <div className={`flex-1 ${message.isBot ? 'pr-12' : 'pl-12'}`}>
                    <div className={`rounded-2xl p-4 ${
                      message.isBot 
                        ? 'bg-card border border-border rounded-tl-none' 
                        : 'bg-primary text-primary-foreground rounded-tr-none'
                    }`}>
                      <p className="whitespace-pre-line leading-relaxed">{message.text}</p>
                    </div>
                  </div>
                </div>
              ))}
              {loading && (
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-primary flex items-center justify-center">
                    <Bot className="w-5 h-5 text-white" />
                  </div>
                  <div className="flex-1 pr-12">
                    <div className="bg-card border border-border rounded-2xl rounded-tl-none p-4">
                      <div className="flex gap-2">
                        <div className="w-2 h-2 bg-primary rounded-full animate-bounce"></div>
                        <div className="w-2 h-2 bg-primary rounded-full animate-bounce delay-100"></div>
                        <div className="w-2 h-2 bg-primary rounded-full animate-bounce delay-200"></div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <div className="p-6 bg-card border-t border-border">
              <div className="flex gap-3">
                <Input
                  placeholder="Digite sua mensagem... (ex: quanto custa?)"
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                  className="flex-1 h-12 rounded-xl border-2 focus:border-primary"
                />
                <Button 
                  onClick={handleSend}
                  size="lg"
                  className="bg-primary hover:bg-primary-hover px-6 rounded-xl"
                  disabled={loading}
                >
                  <Send className="w-5 h-5" />
                </Button>
              </div>
              <p className="text-xs text-muted-foreground mt-3 text-center">
                💡 Tente perguntar: "quanto custa?", "quais as taxas?", "qual a diferença?"
              </p>
            </div>
          </div>

          <div className="mt-8 text-center">
            <Button size="lg" className="bg-gradient-primary hover:opacity-90 text-white font-semibold px-8 py-6 text-lg shadow-primary">
              Quero Essa IA no Meu Negócio
            </Button>
            <p className="text-sm text-muted-foreground mt-4">
              Comece grátis • Sem cartão de crédito • Cancele quando quiser
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ChatDemo;
