import { Brain, Zap, MessageSquare, TrendingUp, Shield, Clock } from "lucide-react";

const Features = () => {
  const features = [
    {
      icon: Brain,
      title: "IA que Aprende Continuamente",
      description: "Cada conversa torna a IA mais inteligente. Ela aprende com sucesso e fracasso, melhorando as taxas de conversão automaticamente.",
      color: "from-primary to-primary-hover"
    },
    {
      icon: MessageSquare,
      title: "WhatsApp + Site Integrado",
      description: "Atenda seus clientes onde eles estão. No WhatsApp Business e no widget do seu site, com a mesma experiência premium.",
      color: "from-accent to-primary"
    },
    {
      icon: Zap,
      title: "Especialista em Ton",
      description: "Conhece profundamente todos os produtos Ton: T1, T2, T3 Max, taxas de 0,59%, planos, diferenciais e como superar objeções.",
      color: "from-success to-primary"
    },
    {
      icon: TrendingUp,
      title: "Vendas no Automático",
      description: "Não apenas responde perguntas. Identifica intenção de compra, apresenta soluções, supera objeções e fecha vendas sozinha.",
      color: "from-primary to-accent"
    },
    {
      icon: Shield,
      title: "Respostas Humanizadas",
      description: "Linguagem natural e personalizada. Seus clientes nem percebem que estão falando com uma IA. Taxa de satisfação de 97%.",
      color: "from-accent to-success"
    },
    {
      icon: Clock,
      title: "Atendimento 24/7",
      description: "Nunca perca uma venda por estar offline. Sua IA trabalha 24 horas, 7 dias por semana, sem pausas, férias ou dias ruins.",
      color: "from-primary to-primary-hover"
    }
  ];

  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-primary/10 px-4 py-2 rounded-full text-sm font-medium text-primary mb-6">
            <Zap className="w-4 h-4" />
            Tecnologia de Ponta
          </div>
          <h2 className="text-4xl lg:text-5xl font-bold text-foreground mb-4">
            IA Especialista em Vender Maquininhas Ton
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Uma ferramenta completa que não apenas responde perguntas, mas vende ativamente seus produtos
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <div 
                key={index}
                className="group bg-card border border-border rounded-2xl p-8 hover:shadow-card transition-all duration-300 hover:-translate-y-1"
              >
                <div className={`w-16 h-16 bg-gradient-to-br ${feature.color} rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                  <Icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-foreground mb-3">{feature.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
              </div>
            );
          })}
        </div>

        <div className="mt-16 bg-gradient-primary rounded-3xl p-12 text-center">
          <h3 className="text-3xl lg:text-4xl font-bold text-white mb-4">
            Transforme visitantes em clientes automaticamente
          </h3>
          <p className="text-xl text-white/90 mb-8 max-w-3xl mx-auto">
            Nossa IA não é um chatbot comum. É um vendedor especialista trabalhando 24/7 para aumentar seu faturamento
          </p>
          <div className="flex flex-wrap justify-center gap-6">
            <div className="text-center">
              <div className="text-5xl font-bold text-white mb-2">5x</div>
              <div className="text-white/90">Mais conversões</div>
            </div>
            <div className="w-px bg-white/20"></div>
            <div className="text-center">
              <div className="text-5xl font-bold text-white mb-2">-80%</div>
              <div className="text-white/90">Custos operacionais</div>
            </div>
            <div className="w-px bg-white/20"></div>
            <div className="text-center">
              <div className="text-5xl font-bold text-white mb-2">24h</div>
              <div className="text-white/90">Disponibilidade</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Features;
