import { AlertCircle, Clock, Users, TrendingDown, DollarSign, Target } from "lucide-react";

const Problems = () => {
  const problems = [
    {
      icon: Clock,
      title: "Atendimento lento e ineficiente",
      description: "Clientes esperando horas por resposta"
    },
    {
      icon: AlertCircle,
      title: "Perda de clientes",
      description: "Vendas perdidas por falta de respostas rápidas"
    },
    {
      icon: Users,
      title: "Time sobrecarregado",
      description: "Equipe desmotivada com tarefas repetitivas"
    },
    {
      icon: TrendingDown,
      title: "Dificuldade em bater metas",
      description: "Vendas inconsistentes e imprevisíveis"
    },
    {
      icon: DollarSign,
      title: "Custo elevado",
      description: "Gastos altos com equipe de atendimento"
    },
    {
      icon: Target,
      title: "Dificuldade em escalar",
      description: "Impossível crescer sem aumentar custos"
    }
  ];

  return (
    <section className="py-20 bg-dark-surface">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-white mb-4">
            Você tem algum desses desafios na sua empresa?
          </h2>
          <p className="text-xl text-white/70 max-w-3xl mx-auto">
            A automação com IA resolve todos esses problemas e aumenta suas vendas exponencialmente
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {problems.map((problem, index) => {
            const Icon = problem.icon;
            return (
              <div 
                key={index}
                className="bg-card border border-border/50 rounded-2xl p-6 hover:border-primary/50 transition-all duration-300 hover:shadow-primary group"
              >
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                  <Icon className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold text-white mb-2">{problem.title}</h3>
                <p className="text-muted-foreground">{problem.description}</p>
              </div>
            );
          })}
        </div>

        <div className="mt-16 text-center">
          <div className="inline-block bg-gradient-primary rounded-2xl p-8 max-w-4xl">
            <h3 className="text-3xl font-bold text-white mb-3">
              O futuro das vendas começa agora
            </h3>
            <p className="text-white/90 text-lg">
              Com nossa IA especializada em maquininhas Ton, você automatiza o atendimento, 
              fecha mais vendas e escala seu negócio sem aumentar custos.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Problems;
