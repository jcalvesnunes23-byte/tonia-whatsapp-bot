import { Button } from "@/components/ui/button";
import { CheckCircle, ArrowRight } from "lucide-react";

const CTA = () => {
  return (
    <section className="py-20 bg-dark-bg relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-20 w-64 h-64 bg-primary/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-20 w-80 h-80 bg-accent/10 rounded-full blur-3xl"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl lg:text-5xl font-bold text-white mb-6">
            Pronto para Automatizar suas Vendas de Maquininhas Ton?
          </h2>
          <p className="text-xl text-white/80 mb-12">
            Junte-se a centenas de vendedores que já aumentaram suas conversões em até 500% com nossa IA especializada
          </p>

          <div className="grid md:grid-cols-3 gap-6 mb-12">
            <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6">
              <CheckCircle className="w-8 h-8 text-primary mx-auto mb-3" />
              <h3 className="text-white font-bold mb-2">Setup em Minutos</h3>
              <p className="text-white/70 text-sm">Integração rápida no WhatsApp e site</p>
            </div>
            <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6">
              <CheckCircle className="w-8 h-8 text-primary mx-auto mb-3" />
              <h3 className="text-white font-bold mb-2">Suporte Premium</h3>
              <p className="text-white/70 text-sm">Time dedicado para seu sucesso</p>
            </div>
            <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6">
              <CheckCircle className="w-8 h-8 text-primary mx-auto mb-3" />
              <h3 className="text-white font-bold mb-2">ROI Garantido</h3>
              <p className="text-white/70 text-sm">Ou devolvemos seu investimento</p>
            </div>
          </div>

          <div className="flex flex-wrap justify-center gap-4">
            <Button 
              size="lg" 
              className="bg-primary hover:bg-primary-hover text-white font-bold px-10 py-7 text-lg shadow-primary group"
            >
              Começar Agora Grátis
              <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Button>
            <Button 
              size="lg" 
              variant="outline"
              className="border-2 border-white text-white hover:bg-white/10 font-bold px-10 py-7 text-lg"
            >
              Agendar Demonstração
            </Button>
          </div>

          <p className="text-white/60 text-sm mt-6">
            ✨ Teste grátis por 14 dias • Sem cartão de crédito • Cancele quando quiser
          </p>
        </div>
      </div>
    </section>
  );
};

export default CTA;
