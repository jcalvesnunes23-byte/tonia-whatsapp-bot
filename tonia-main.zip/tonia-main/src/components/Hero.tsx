import { Button } from "@/components/ui/button";
import { MessageSquare, Zap, TrendingUp } from "lucide-react";

const Hero = () => {
  const scrollToDemo = () => {
    document.getElementById('chatbot-demo')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden bg-gradient-hero">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-primary/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-accent/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left side - Content */}
          <div className="text-white space-y-6">
            <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full text-sm font-medium">
              <Zap className="w-4 h-4" />
              Automação com IA para WhatsApp
            </div>
            
            <h1 className="text-5xl lg:text-6xl font-bold leading-tight">
              Nunca foi tão fácil criar{" "}
              <span className="text-white drop-shadow-lg">automações milionárias</span>
              , e agora sua IA também vende por você.
            </h1>
            
            <p className="text-xl text-white/90 leading-relaxed">
              Esqueça o atendimento manual. Sua IA especialista em maquininhas Ton aprende com cada conversa e fecha vendas automaticamente no WhatsApp e no seu site.
            </p>

            <div className="flex flex-wrap gap-4 pt-4">
              <Button 
                size="lg" 
                onClick={scrollToDemo}
                className="bg-white text-primary hover:bg-white/90 font-semibold px-8 py-6 text-lg shadow-xl hover:scale-105 transition-transform"
              >
                Testar Agora Grátis
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="border-2 border-white text-white hover:bg-white/10 backdrop-blur-sm font-semibold px-8 py-6 text-lg"
              >
                Ver Como Funciona
              </Button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6 pt-8">
              <div className="text-center lg:text-left">
                <div className="text-3xl font-bold text-white">97%</div>
                <div className="text-sm text-white/80">Taxa de Conversão</div>
              </div>
              <div className="text-center lg:text-left">
                <div className="text-3xl font-bold text-white">24/7</div>
                <div className="text-sm text-white/80">Atendimento</div>
              </div>
              <div className="text-center lg:text-left">
                <div className="text-3xl font-bold text-white">+500%</div>
                <div className="text-sm text-white/80">Mais Vendas</div>
              </div>
            </div>
          </div>

          {/* Right side - Visual */}
          <div className="relative hidden lg:block">
            <div className="relative bg-white rounded-3xl shadow-2xl p-8 backdrop-blur-sm bg-white/95">
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <MessageSquare className="w-5 h-5 text-primary" />
                  </div>
                  <div className="flex-1">
                    <div className="bg-secondary rounded-2xl rounded-tl-none p-4">
                      <p className="text-sm text-foreground">Olá! Quero saber mais sobre as maquininhas Ton. Quais são as taxas?</p>
                    </div>
                  </div>
                </div>

                <div className="flex items-start gap-3 flex-row-reverse">
                  <div className="w-10 h-10 rounded-full bg-gradient-primary flex items-center justify-center">
                    <Zap className="w-5 h-5 text-white" />
                  </div>
                  <div className="flex-1">
                    <div className="bg-gradient-primary rounded-2xl rounded-tr-none p-4">
                      <p className="text-sm text-white">Perfeito! A Ton tem as melhores taxas do mercado. No plano Max você paga apenas 0,59% no débito e crédito. Posso te mostrar qual maquininha é ideal para você?</p>
                    </div>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <MessageSquare className="w-5 h-5 text-primary" />
                  </div>
                  <div className="flex-1">
                    <div className="bg-secondary rounded-2xl rounded-tl-none p-4">
                      <p className="text-sm text-foreground">Sim, por favor! Quanto custa?</p>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-center gap-2 text-primary py-4">
                  <TrendingUp className="w-5 h-5 animate-bounce" />
                  <span className="text-sm font-semibold">Vendendo automaticamente...</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
