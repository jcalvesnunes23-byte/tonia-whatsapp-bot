import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { User, Mail, Phone, MessageSquare } from "lucide-react";
import { z } from "zod";

const leadSchema = z.object({
  name: z.string().trim().min(2, 'Nome deve ter no mínimo 2 caracteres').max(100, 'Nome muito longo'),
  email: z.string().trim().email('Email inválido').max(255, 'Email muito longo'),
  phone: z.string().trim().min(10, 'Telefone inválido').max(20, 'Telefone muito longo'),
  interest: z.string().trim().min(10, 'Descreva melhor seu interesse (mínimo 10 caracteres)').max(500, 'Descrição muito longa')
});

const LeadForm = () => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    interest: ""
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      // Validate input
      const validated = leadSchema.parse(formData);
      
      // Check rate limiting
      const lastSubmit = localStorage.getItem('lastLeadSubmit');
      if (lastSubmit && Date.now() - parseInt(lastSubmit) < 60000) {
        toast({
          title: "Aguarde um momento",
          description: "Por favor, aguarde 1 minuto entre envios",
          variant: "destructive"
        });
        setLoading(false);
        return;
      }

      const { error } = await supabase
        .from('leads')
        .insert([validated]);

      if (error) throw error;
      
      // Set rate limit timestamp
      localStorage.setItem('lastLeadSubmit', Date.now().toString());

      toast({
        title: "Obrigado!",
        description: "Recebemos seu interesse. Em breve entraremos em contato!",
      });

      setFormData({
        name: "",
        email: "",
        phone: "",
        interest: ""
      });
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        toast({
          title: "Dados inválidos",
          description: error.errors[0].message,
          variant: "destructive"
        });
      } else {
        console.error('Error submitting lead:', error);
        toast({
          title: "Erro",
          description: "Não foi possível enviar seus dados. Tente novamente.",
          variant: "destructive"
        });
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl lg:text-5xl font-bold text-foreground mb-4">
              Fale com um Especialista
            </h2>
            <p className="text-xl text-muted-foreground">
              Deixe seus dados e receba uma proposta personalizada
            </p>
          </div>

          <form onSubmit={handleSubmit} className="bg-card border border-border rounded-3xl p-8 shadow-card space-y-6">
            <div className="space-y-2">
              <Label htmlFor="name">Nome Completo</Label>
              <div className="relative">
                <User className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
                <Input
                  id="name"
                  type="text"
                  placeholder="Seu nome"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="pl-10"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
                <Input
                  id="email"
                  type="email"
                  placeholder="seu@email.com"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="pl-10"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone">Telefone</Label>
              <div className="relative">
                <Phone className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
                <Input
                  id="phone"
                  type="tel"
                  placeholder="(00) 00000-0000"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="pl-10"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="interest">Conte-nos sobre seu interesse</Label>
              <div className="relative">
                <MessageSquare className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
                <Textarea
                  id="interest"
                  placeholder="Ex: Preciso de maquininhas para meu restaurante..."
                  value={formData.interest}
                  onChange={(e) => setFormData({ ...formData, interest: e.target.value })}
                  className="pl-10 min-h-[100px]"
                  required
                />
              </div>
            </div>

            <Button
              type="submit"
              className="w-full bg-gradient-primary hover:opacity-90 text-white font-semibold py-6 text-lg"
              disabled={loading}
            >
              {loading ? "Enviando..." : "Quero Receber uma Proposta"}
            </Button>

            <p className="text-xs text-muted-foreground text-center">
              Seus dados estão seguros conosco e não serão compartilhados.
            </p>
          </form>
        </div>
      </div>
    </section>
  );
};

export default LeadForm;