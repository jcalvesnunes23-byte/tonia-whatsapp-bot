import { Card } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { AlertTriangle, Server, QrCode, ArrowRight } from "lucide-react";

export const BaileysSetup = () => {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2">Integração WhatsApp via QR Code (Baileys)</h2>
        <p className="text-muted-foreground">
          Configure o driver Baileys em um servidor Node.js separado para conectar WhatsApp via QR Code
        </p>
      </div>

      <Alert variant="destructive">
        <AlertTriangle className="h-4 w-4" />
        <AlertDescription>
          <strong>IMPORTANTE:</strong> O driver Baileys precisa rodar em um servidor Node.js separado 
          (VPS, Railway, Render, etc.). Ele NÃO funciona diretamente no Lovable/navegador.
        </AlertDescription>
      </Alert>

      <Card className="p-6">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <Server className="h-5 w-5" />
          Passo a Passo
        </h3>
        
        <div className="space-y-4">
          <div className="flex gap-4">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold">
              1
            </div>
            <div className="flex-1">
              <h4 className="font-semibold mb-1">Prepare o Servidor Node.js</h4>
              <p className="text-sm text-muted-foreground mb-2">
                Acesse seu servidor (VPS, Railway, etc.) ou use seu computador local para testes
              </p>
              <div className="bg-muted p-3 rounded-md font-mono text-xs">
                # Baixe os arquivos da pasta baileys-driver/<br/>
                cd baileys-driver<br/>
                npm install
              </div>
            </div>
          </div>

          <div className="flex gap-4">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold">
              2
            </div>
            <div className="flex-1">
              <h4 className="font-semibold mb-1">Configure as Variáveis de Ambiente</h4>
              <p className="text-sm text-muted-foreground mb-2">
                Copie .env.example para .env e configure o webhook da TonIA
              </p>
              <div className="bg-muted p-3 rounded-md font-mono text-xs">
                TONIA_WEBHOOK=https://thraezhbnxzgkzgszjsy.supabase.co/functions/v1/whatsapp-webhook<br/>
                DRIVER_SECRET=seu_secret_super_seguro<br/>
                PORT=3001
              </div>
            </div>
          </div>

          <div className="flex gap-4">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold">
              3
            </div>
            <div className="flex-1">
              <h4 className="font-semibold mb-1">Inicie o Driver</h4>
              <p className="text-sm text-muted-foreground mb-2">
                Execute o servidor e acesse o endpoint /qr para gerar o QR Code
              </p>
              <div className="bg-muted p-3 rounded-md font-mono text-xs">
                npm start<br/>
                # Acesse: http://SEU_SERVIDOR:3001/qr
              </div>
            </div>
          </div>

          <div className="flex gap-4">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold">
              4
            </div>
            <div className="flex-1">
              <h4 className="font-semibold mb-1 flex items-center gap-2">
                <QrCode className="h-4 w-4" />
                Escaneie o QR Code
              </h4>
              <p className="text-sm text-muted-foreground">
                Abra o WhatsApp no celular → Aparelhos conectados → Conectar aparelho → Escaneie o QR
              </p>
            </div>
          </div>
        </div>
      </Card>

      <Card className="p-6 border-amber-500/50 bg-amber-500/5">
        <h3 className="text-lg font-semibold mb-3 flex items-center gap-2 text-amber-600 dark:text-amber-400">
          <AlertTriangle className="h-5 w-5" />
          Avisos Importantes
        </h3>
        <ul className="space-y-2 text-sm text-muted-foreground">
          <li className="flex gap-2">
            <span className="text-amber-600 dark:text-amber-400">•</span>
            <span><strong>Baileys é não-oficial</strong> e pode violar os Termos de Serviço do WhatsApp</span>
          </li>
          <li className="flex gap-2">
            <span className="text-amber-600 dark:text-amber-400">•</span>
            <span>Use apenas para <strong>desenvolvimento e testes</strong></span>
          </li>
          <li className="flex gap-2">
            <span className="text-amber-600 dark:text-amber-400">•</span>
            <span>Para produção, migre para <strong>WhatsApp Cloud API oficial</strong></span>
          </li>
          <li className="flex gap-2">
            <span className="text-amber-600 dark:text-amber-400">•</span>
            <span>Uso inadequado pode resultar em <strong>banimento do número</strong></span>
          </li>
        </ul>
      </Card>

      <Card className="p-6 bg-primary/5 border-primary/20">
        <h3 className="text-lg font-semibold mb-3">Arquitetura da Integração</h3>
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-sm">
          <div className="flex flex-col items-center text-center">
            <div className="w-12 h-12 rounded-full bg-green-500 text-white flex items-center justify-center mb-2">
              <QrCode className="h-6 w-6" />
            </div>
            <span className="font-semibold">WhatsApp</span>
            <span className="text-xs text-muted-foreground">Cliente</span>
          </div>
          <ArrowRight className="h-6 w-6 text-muted-foreground rotate-90 md:rotate-0" />
          <div className="flex flex-col items-center text-center">
            <div className="w-12 h-12 rounded-full bg-blue-500 text-white flex items-center justify-center mb-2">
              <Server className="h-6 w-6" />
            </div>
            <span className="font-semibold">Baileys Driver</span>
            <span className="text-xs text-muted-foreground">Node.js Server</span>
          </div>
          <ArrowRight className="h-6 w-6 text-muted-foreground rotate-90 md:rotate-0" />
          <div className="flex flex-col items-center text-center">
            <div className="w-12 h-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center mb-2">
              <span className="font-bold">AI</span>
            </div>
            <span className="font-semibold">TonIA Webhook</span>
            <span className="text-xs text-muted-foreground">Edge Function</span>
          </div>
        </div>
      </Card>

      <div className="flex gap-3">
        <Button variant="outline" asChild>
          <a href="https://github.com/WhiskeySockets/Baileys" target="_blank" rel="noopener noreferrer">
            Documentação Baileys
          </a>
        </Button>
        <Button variant="outline" asChild>
          <a href="https://developers.facebook.com/docs/whatsapp" target="_blank" rel="noopener noreferrer">
            WhatsApp Cloud API (Oficial)
          </a>
        </Button>
      </div>
    </div>
  );
};
