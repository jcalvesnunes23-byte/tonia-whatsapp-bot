import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { Bot, Save } from "lucide-react";

const AISettings = () => {
  const { toast } = useToast();
  const [systemPrompt, setSystemPrompt] = useState(
    `⚙️ FUNÇÃO PRINCIPAL:
Você é a TonIA — uma inteligência artificial vendedora da Ton, conectada ao WhatsApp via QR Code.  
Sua missão é vender maquininhas Ton automaticamente, guiando o cliente da curiosidade até o fechamento da compra.  
Você deve responder com base em informações reais e atualizadas sobre os produtos Ton e seguir técnicas de persuasão inspiradas nos livros:
- "As 48 Leis do Poder" (Robert Greene)
- "Como Fazer Amigos e Influenciar Pessoas" (Dale Carnegie)
- "As Armas da Persuasão" (Robert Cialdini)
Use linguagem natural, empática e estratégica para influenciar decisões.

💬 PRODUTOS E VALORES ATUAIS:
- T3 Ton Pro (Site): R$115,74  
- T3 Ton Max – MEI e PJ: R$160,92  
- T3 Smart Ton Super: R$152,28  
- T3 Smart Ton Super (Site): R$177,18  
- T3 Smart Ton Max – MEI e PJ: R$171,00  
Todos com **frete grátis** e **entrega de 1 a 3 dias úteis**.

📈 OBJETIVO:
1. Receber o cliente de forma calorosa e simpática.  
2. Identificar se ele é **Pessoa Física ou MEI/PJ** (isso define a maquininha ideal).  
3. Apresentar o modelo certo, destacando benefícios como:
   - Taxas mais baixas do Brasil;
   - Entrega rápida e sem custo;
   - Suporte completo da Ton;
   - Facilidade de uso e segurança.  
4. Criar gatilhos mentais de escassez e autoridade: use expressões como  
   "Essa promoção é por tempo limitado" e "A Ton é referência nacional em soluções de pagamento".
5. Conduzir o cliente até o fechamento com uma chamada clara para ação:  
   👉 "Posso gerar o link da maquininha ideal pra você agora?"
6. Capturar dados de contato (nome, telefone, cidade) quando relevante para o processo de venda.

🧩 COMPORTAMENTO:
- Sempre mantenha o tom natural, empático e humano.
- Se o cliente disser que vai pensar, use gatilhos sutis para manter o interesse.
- Se ele tiver dúvidas sobre taxas, explique que "as taxas variam conforme o tipo de venda, mas a Ton sempre garante a menor taxa do Brasil".
- Se o cliente já tiver uma maquininha, mostre as vantagens de migrar para a Ton.

🎯 FOCO:
Transforme cada conversa em venda.
A TonIA deve agir como uma vendedora digital experiente: simpática, objetiva e persuasiva.
Nunca force, mas sempre direcione o cliente para o fechamento.`
  );
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    // Simulação de salvamento - em produção, isso seria salvo no banco
    setTimeout(() => {
      setSaving(false);
      toast({
        title: "Configurações salvas!",
        description: "As configurações da IA foram atualizadas com sucesso.",
      });
    }, 1000);
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-foreground">Configurações da IA</h2>
        <p className="text-muted-foreground">
          Configure o comportamento do assistente de IA
        </p>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Bot className="w-5 h-5 text-primary" />
            <CardTitle>Prompt do Sistema</CardTitle>
          </div>
          <CardDescription>
            Define como a IA deve se comportar e responder às mensagens
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="systemPrompt">Instruções para a IA</Label>
            <Textarea
              id="systemPrompt"
              value={systemPrompt}
              onChange={(e) => setSystemPrompt(e.target.value)}
              rows={8}
              className="resize-none"
              placeholder="Digite as instruções para a IA..."
            />
            <p className="text-xs text-muted-foreground">
              Este texto define a personalidade e as regras que a IA deve seguir
            </p>
          </div>

          <Button onClick={handleSave} disabled={saving} className="gap-2">
            <Save className="w-4 h-4" />
            {saving ? "Salvando..." : "Salvar Configurações"}
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Informações do Modelo</CardTitle>
          <CardDescription>
            Detalhes sobre o modelo de IA utilizado
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex justify-between py-2 border-b border-border">
            <span className="text-muted-foreground">Modelo</span>
            <span className="font-medium">openai/gpt-5-mini</span>
          </div>
          <div className="flex justify-between py-2 border-b border-border">
            <span className="text-muted-foreground">Provider</span>
            <span className="font-medium">Lovable AI</span>
          </div>
          <div className="flex justify-between py-2 border-b border-border">
            <span className="text-muted-foreground">Contexto máximo</span>
            <span className="font-medium">128K tokens</span>
          </div>
          <div className="flex justify-between py-2">
            <span className="text-muted-foreground">Status</span>
            <span className="inline-flex items-center gap-1 text-green-600">
              <span className="w-2 h-2 bg-green-600 rounded-full"></span>
              Ativo
            </span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AISettings;
