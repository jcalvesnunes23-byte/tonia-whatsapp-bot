import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { Smartphone, Check, X, Copy, QrCode } from "lucide-react";
import QRCode from "react-qr-code";

interface WhatsAppIntegration {
  id: string;
  phone_number: string;
  phone_number_id: string;
  business_account_id: string | null;
  is_active: boolean;
  created_at: string;
}

const WhatsAppIntegration = () => {
  const { toast } = useToast();
  const [integrations, setIntegrations] = useState<WhatsAppIntegration[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [showQR, setShowQR] = useState(false);

  // Form states
  const [phoneNumber, setPhoneNumber] = useState("");
  const [accessToken, setAccessToken] = useState("");
  const [phoneNumberId, setPhoneNumberId] = useState("");
  const [businessAccountId, setBusinessAccountId] = useState("");
  const [webhookToken, setWebhookToken] = useState("");

  const webhookUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/whatsapp-webhook`;

  const generateQRCode = () => {
    setShowQR(true);
  };

  useEffect(() => {
    loadIntegrations();
  }, []);

  const loadIntegrations = async () => {
    try {
      const { data, error } = await supabase
        .from('whatsapp_integrations')
        .select('id, phone_number, phone_number_id, business_account_id, is_active, created_at')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setIntegrations(data || []);
    } catch (error: any) {
      console.error('Error loading integrations:', error);
      toast({
        title: "Erro ao carregar integrações",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Usuário não autenticado");

      const { error } = await supabase
        .from('whatsapp_integrations')
        .insert({
          user_id: user.id,
          phone_number: phoneNumber,
          access_token: accessToken,
          phone_number_id: phoneNumberId,
          business_account_id: businessAccountId || null,
          webhook_verify_token: webhookToken,
          is_active: true,
        });

      if (error) throw error;

      toast({
        title: "Integração criada!",
        description: "WhatsApp integrado com sucesso.",
      });

      setShowForm(false);
      setPhoneNumber("");
      setAccessToken("");
      setPhoneNumberId("");
      setBusinessAccountId("");
      setWebhookToken("");
      loadIntegrations();
    } catch (error: any) {
      console.error('Error creating integration:', error);
      toast({
        title: "Erro ao criar integração",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const toggleIntegration = async (id: string, currentStatus: boolean) => {
    try {
      const { error } = await supabase
        .from('whatsapp_integrations')
        .update({ is_active: !currentStatus })
        .eq('id', id);

      if (error) throw error;

      toast({
        title: currentStatus ? "Integração desativada" : "Integração ativada",
      });

      loadIntegrations();
    } catch (error: any) {
      console.error('Error toggling integration:', error);
      toast({
        title: "Erro",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copiado!",
      description: "URL copiada para a área de transferência",
    });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Integração WhatsApp</h2>
          <p className="text-muted-foreground">
            Configure o WhatsApp Business API para automatizar conversas
          </p>
        </div>
        <div className="flex gap-2">
          <Button 
            onClick={generateQRCode}
            variant="outline"
            className="gap-2"
          >
            <QrCode className="w-4 h-4" />
            Gerar QR Code
          </Button>
          {!showForm && (
            <Button onClick={() => setShowForm(true)} className="gap-2">
              <Smartphone className="w-4 h-4" />
              Nova Integração
            </Button>
          )}
        </div>
      </div>

      {showForm && (
        <Card>
          <CardHeader>
            <CardTitle>Configurar WhatsApp Business API</CardTitle>
            <CardDescription>
              Preencha os dados da sua conta WhatsApp Business
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="webhookUrl">URL do Webhook</Label>
                <div className="flex gap-2">
                  <Input
                    id="webhookUrl"
                    value={webhookUrl}
                    readOnly
                    className="flex-1"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    size="icon"
                    onClick={() => copyToClipboard(webhookUrl)}
                  >
                    <Copy className="w-4 h-4" />
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">
                  Use esta URL no painel do WhatsApp Business
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="webhookToken">Token de Verificação do Webhook</Label>
                <Input
                  id="webhookToken"
                  value={webhookToken}
                  onChange={(e) => setWebhookToken(e.target.value)}
                  placeholder="Crie um token secreto"
                  required
                />
                <p className="text-xs text-muted-foreground">
                  Crie um token único para validar o webhook
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="phoneNumber">Número de Telefone</Label>
                <Input
                  id="phoneNumber"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  placeholder="+55 11 99999-9999"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="phoneNumberId">Phone Number ID</Label>
                <Input
                  id="phoneNumberId"
                  value={phoneNumberId}
                  onChange={(e) => setPhoneNumberId(e.target.value)}
                  placeholder="ID do número no WhatsApp Business"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="accessToken">Access Token</Label>
                <Input
                  id="accessToken"
                  type="password"
                  value={accessToken}
                  onChange={(e) => setAccessToken(e.target.value)}
                  placeholder="Token de acesso do WhatsApp Business"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="businessAccountId">Business Account ID (Opcional)</Label>
                <Input
                  id="businessAccountId"
                  value={businessAccountId}
                  onChange={(e) => setBusinessAccountId(e.target.value)}
                  placeholder="ID da conta business"
                />
              </div>

              <div className="flex gap-2">
                <Button type="submit" disabled={loading}>
                  {loading ? "Salvando..." : "Salvar Integração"}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setShowForm(false)}
                >
                  Cancelar
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {integrations.length === 0 && !showForm ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Smartphone className="w-16 h-16 text-muted-foreground mb-4" />
            <p className="text-muted-foreground text-center">
              Nenhuma integração configurada ainda.
              <br />
              Clique em "Nova Integração" para começar.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {integrations.map((integration) => (
            <Card key={integration.id}>
              <CardContent className="flex items-center justify-between p-6">
                <div className="flex items-center gap-4">
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                    integration.is_active ? 'bg-green-100' : 'bg-gray-100'
                  }`}>
                    <Smartphone className={`w-6 h-6 ${
                      integration.is_active ? 'text-green-600' : 'text-gray-400'
                    }`} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground">
                      {integration.phone_number}
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      ID: {integration.phone_number_id}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Criado em {new Date(integration.created_at).toLocaleDateString('pt-BR')}
                    </p>
                  </div>
                </div>
                <Button
                  variant={integration.is_active ? "destructive" : "default"}
                  onClick={() => toggleIntegration(integration.id, integration.is_active)}
                  className="gap-2"
                >
                  {integration.is_active ? (
                    <>
                      <X className="w-4 h-4" />
                      Desativar
                    </>
                  ) : (
                    <>
                      <Check className="w-4 h-4" />
                      Ativar
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
      
      <Dialog open={showQR} onOpenChange={setShowQR}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>QR Code de Integração WhatsApp</DialogTitle>
          </DialogHeader>
          <div className="flex flex-col items-center gap-4 p-4">
            <div className="bg-white p-4 rounded-lg">
              <QRCode 
                value={JSON.stringify({
                  webhook_url: webhookUrl,
                  verify_token: webhookToken || "TonAI_Webhook_2025",
                  instructions: "Configure seu WhatsApp Business API com estas informações"
                })} 
                size={256} 
              />
            </div>
            <div className="text-sm text-muted-foreground text-center space-y-2">
              <p className="font-semibold">Como usar:</p>
              <ol className="text-left space-y-1 list-decimal list-inside">
                <li>Escaneie este QR code</li>
                <li>Use as informações para configurar o WhatsApp Business API</li>
                <li>Configure o webhook com a URL fornecida</li>
              </ol>
              <div className="pt-2 text-xs">
                <p className="font-medium">Webhook URL:</p>
                <code className="bg-muted px-2 py-1 rounded text-xs break-all">{webhookUrl}</code>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default WhatsAppIntegration;
