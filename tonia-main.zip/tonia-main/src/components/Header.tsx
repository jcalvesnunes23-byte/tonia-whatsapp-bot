import { Button } from "@/components/ui/button";
import { MessageSquare, Menu, Lock } from "lucide-react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import ThemeToggle from "@/components/ThemeToggle";

const Header = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const navigate = useNavigate();

  const scrollToSection = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
    setMobileMenuOpen(false);
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border shadow-sm">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-gradient-primary rounded-xl flex items-center justify-center">
              <MessageSquare className="w-6 h-6 text-white" />
            </div>
            <span className="text-2xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              TonAI
            </span>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            <button 
              onClick={() => scrollToSection('hero')}
              className="text-foreground hover:text-primary font-medium transition-colors"
            >
              Início
            </button>
            <button 
              onClick={() => scrollToSection('features')}
              className="text-foreground hover:text-primary font-medium transition-colors"
            >
              Funcionalidades
            </button>
            <button 
              onClick={() => scrollToSection('chatbot-demo')}
              className="text-foreground hover:text-primary font-medium transition-colors"
            >
              Demo
            </button>
          </nav>

          {/* CTA Button */}
          <div className="hidden md:flex items-center gap-3">
            <ThemeToggle />
            <Button 
              variant="ghost"
              onClick={() => navigate("/auth")}
              className="gap-2"
            >
              <Lock className="w-4 h-4" />
              Admin
            </Button>
            <Button 
              className="bg-gradient-primary hover:opacity-90 text-white font-semibold px-6"
              onClick={() => scrollToSection('chatbot-demo')}
            >
              Teste Grátis
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center gap-2">
            <ThemeToggle />
            <button 
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              <Menu className="w-6 h-6 text-foreground" />
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden py-4 border-t border-border">
            <nav className="flex flex-col gap-4">
              <button 
                onClick={() => scrollToSection('hero')}
                className="text-foreground hover:text-primary font-medium transition-colors text-left"
              >
                Início
              </button>
              <button 
                onClick={() => scrollToSection('features')}
                className="text-foreground hover:text-primary font-medium transition-colors text-left"
              >
                Funcionalidades
              </button>
              <button 
                onClick={() => scrollToSection('chatbot-demo')}
                className="text-foreground hover:text-primary font-medium transition-colors text-left"
              >
                Demo
              </button>
              <Button 
                variant="ghost"
                onClick={() => navigate("/auth")}
                className="w-full gap-2 justify-start"
              >
                <Lock className="w-4 h-4" />
                Admin
              </Button>
              <Button 
                className="bg-gradient-primary hover:opacity-90 text-white font-semibold w-full"
                onClick={() => scrollToSection('chatbot-demo')}
              >
                Teste Grátis
              </Button>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
